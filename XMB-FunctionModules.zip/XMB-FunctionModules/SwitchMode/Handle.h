#ifndef __Handle_H__
#define __Handle_H__
#include "TCP-CH/tcp.h"



void DAP_Handle(void);
void UART_Handle(void);
void ADC_Handle(void);
void DAC_Handle(void);
void PWM_Collect_Handle(void);
void PWM_Simulation_Handle(void);
void I2C_Handle(void);
void SPI_Handle(void);
void CAN_Handle(void);


void uart_task(int ksock);

#endif